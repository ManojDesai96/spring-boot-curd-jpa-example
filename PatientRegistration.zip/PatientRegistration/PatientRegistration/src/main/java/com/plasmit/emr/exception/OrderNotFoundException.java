package com.plasmit.emr.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "No such order")
public class OrderNotFoundException extends Exception {
	
	private static final long serialVersionUID = -47986654554555L;
	
	public OrderNotFoundException(String errorMessage) {
		super(errorMessage + " not found");
	}
 

}
