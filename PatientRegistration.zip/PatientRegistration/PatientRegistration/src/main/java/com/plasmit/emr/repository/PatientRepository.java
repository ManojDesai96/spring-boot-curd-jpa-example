package com.plasmit.emr.repository;

import org.springframework.data.repository.CrudRepository;

import com.plasmit.emr.model.Patient;

public interface PatientRepository extends CrudRepository<Patient,Integer> {

}
