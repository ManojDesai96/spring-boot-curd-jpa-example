package com.plasmit.emr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.plasmit.emr.exception.OrderNotFoundException;
import com.plasmit.emr.model.Patient;
import com.plasmit.emr.services.PatientServices;

@RestController
public class PatientController {
	
	//public static Logger Logger =LoggerFactory.getLogger(PatientController.class);
	
	@Autowired
	PatientServices patientservices;

	@GetMapping("/Patient")
	private List<Patient> getAllPatient(){
		return patientservices.getAllPatient();
	}
	
	//savePatient method is used to store data on database
	@PostMapping("/Patient")
	private int savePatient(@RequestBody Patient patient){
		patientservices.saveOrUpdate(patient);
		return patient.getPid();
	}
	
	//finding data by using id handling exception
	@RequestMapping(path ="/Patient/{pid}" , produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Patient> getPatientById(@PathVariable("pid") Integer pid) throws OrderNotFoundException{
		Patient patient = patientservices.getPatientById(pid).orElseThrow(() -> new OrderNotFoundException("Patient ID not found with ID ="+pid));
		return ResponseEntity.ok().body(patient);
	}
	
	
	/*
	 * @GetMapping("/Patient/{pid}") private Patient getPatient(@PathVariable("pid")
	 * int pid) {
	 * 
	 * return patientservices.getPatientById(pid); }
	 */
	 
	
	//delete record by using id
	@DeleteMapping("/Patient/{pid}")
	private void deletePatient(@PathVariable("pid") int pid)  {
		 patientservices.detete(pid);
	}
	
	//create put mapping that update the patient details
	@PutMapping("/Patient")
	private Patient update(@RequestBody Patient patient) {
		patientservices.saveOrUpdate(patient);
		return patient;
	}
}
