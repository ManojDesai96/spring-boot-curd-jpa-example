package com.plasmit.emr.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.plasmit.emr.model.Patient;
import com.plasmit.emr.repository.PatientRepository;

@Service
public class PatientServices {
	
	@Autowired
	PatientRepository patientRepository;
	
	//find all data show records
	public List<Patient> getAllPatient() {
		List<Patient> patients = new ArrayList<Patient>();
		patientRepository.findAll().forEach(patient -> patients.add(patient));
		return patients;
	}
	
	//save records in database
	public void saveOrUpdate(Patient patient) {
		patientRepository.save(patient);
		
	}
	
	//find record by using patient id 
	public Optional<Patient> getPatientById(Integer pid)  {
		return patientRepository.findById(pid);
	}
	
	//delete record using by id
	public void detete(int pid) {
		patientRepository.deleteById(pid);
	}
	
	//update record in database patient details
	public void saveOrUpdate(Patient patient, int pid) {
		patientRepository.save(patient);
	}
}

