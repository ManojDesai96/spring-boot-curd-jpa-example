package com.plasmit.emr.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
	
	
	/*
	 * @ExceptionHandler(Exception.class) //override method
	 * ofResponseEntityExceptionHandler public final ResponseEntity<Object>
	 * handleAllExceptions(Exception ex, WebRequest request) { //creating exception
	 * response structure ExceptionResponse exceptionResponse= new
	 * 
	 * //returning exception structure and specific return new
	 * ResponseEntity<Object>(ex ,HttpStatus.), HttpStatus.INTERNAL_SERVER_ERROR); }
	 */
	
	
	
	
	@ExceptionHandler(OrderNotFoundException.class)
	public final ResponseEntity<Object> handleUserNotFound
	(OrderNotFoundException accessExceptio, WebRequest req){
		List<String> details = new ArrayList<>();
		details.add(accessExceptio.getLocalizedMessage());
		ExceptionResponse error = new ExceptionResponse("Record not found", details);
		return new ResponseEntity<Object> (error,HttpStatus.NOT_FOUND);
		
	}

}
